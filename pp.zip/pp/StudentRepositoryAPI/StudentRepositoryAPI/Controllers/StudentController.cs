﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StudentRepositoryAPI.Models;

namespace StudentRepositoryAPI.Controllers
{
    public class StudentController : ApiController
    {
        private readonly Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();

        [HttpGet]
        public List<StudentDetail> GetAllStudents()
        {
            db.Configuration.LazyLoadingEnabled = false;
            return db.StudentDetails.ToList();
        }

        [HttpGet]
        public StudentDetail GetStudentById(int? studentid)
        {
            return db.StudentDetails.Where(a => a.studentid == studentid).SingleOrDefault();
        }

        [HttpGet]
        public HttpResponseMessage DeleteStudent(int? studentid)
        {
            var IsStudentExists = db.StudentDetails.Where(a => a.studentid == studentid).SingleOrDefault();
            if (IsStudentExists != null)
            {
                db.StudentDetails.Remove(IsStudentExists);
                db.SaveChanges();
                return Request.CreateResponse(HttpStatusCode.OK, "Successfully Deleted");
            }
            return Request.CreateResponse(HttpStatusCode.NotFound, $"No Student Found By this {studentid}");
        }

        [HttpGet]
        public IHttpActionResult AppliedJobs(int? studentid)
        {
            var jobsApplied = db.JobsApplieds.Include("Job").Where(a => a.studentid == studentid).ToList();
            if (jobsApplied != null)
            {
                return Ok(jobsApplied);
            }
            return NotFound();
        }

        [HttpPost]
        public HttpResponseMessage EditDetails(StudentDetail student)
        {
            var res = db.StudentDetails.Where(a => a.studentid != student.studentid && a.mobileno == student.mobileno).ToList();
            if (res.Count > 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Mobile Number Already Registered");
            }
            StudentDetail student1 = db.StudentDetails.Find(student.studentid);
            student1.studentname = student.studentname;
            student1.age = student.age;
            student1.dob = student.dob;
            student1.gender = student.gender;
            student1.mobileno = student.mobileno;
            student1.address = student.address;
            student1.password = student.password;
            student1.email = student.email;
            db.Entry(student1).State = EntityState.Modified;
            db.SaveChanges();
            return Request.CreateResponse(HttpStatusCode.OK, "Successfully Changed");
        }
    }
}
