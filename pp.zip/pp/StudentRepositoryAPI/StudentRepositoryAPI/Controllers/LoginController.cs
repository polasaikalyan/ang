﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StudentRepositoryAPI.Models;

namespace StudentRepositoryAPI.Controllers
{
    public class LoginController : ApiController
    {

        private readonly Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();


        [HttpPost]
        public HttpResponseMessage StudentRegister(StudentDetail student)
        {
            var res = db.StudentDetails.Where(a => a.studentid != student.studentid && a.mobileno == student.mobileno).ToList();
            if (res.Count > 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Mobile Number Already Registered");
            }
            db.StudentDetails.Add(student);
            db.SaveChanges();
            return Request.CreateResponse(HttpStatusCode.OK, "Successfully Registered");
        }

        [HttpGet]
        public HttpResponseMessage StudentLogin(int? studentid, string password)
        {
            db.Configuration.LazyLoadingEnabled = false;
            var IsStudentExists = db.StudentDetails.Where(a => a.studentid == studentid).SingleOrDefault();
            if (IsStudentExists != null)
            {
                if (IsStudentExists.password == password)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, IsStudentExists);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Password InCorrect");
                }
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "StudentId Not Found");
            }
        }

        [HttpGet]
        public HttpResponseMessage AdminLogin(int? adminid, string password)
        {
            var IsAdminExists = db.AdminLoginDetails.Where(a => a.adminid == adminid).SingleOrDefault();
            if (IsAdminExists != null)
            {
                if (IsAdminExists.adminpassword == password)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, IsAdminExists);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Password InCorrect");
                }
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NotFound, "AdminId Not Found");
            }
        }        
    }
}
