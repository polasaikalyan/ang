﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StudentRepositoryAPI.Models;

namespace StudentRepositoryAPI.Controllers
{
    public class AdminController : ApiController
    {
        private readonly Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();

        public HttpResponseMessage AddNewJob(Job job)
        {
            job.createddate = DateTime.Now.Date;
            db.Jobs.Add(job);
            db.SaveChanges();
            return Request.CreateResponse(HttpStatusCode.OK, job);
        }
    }
}
